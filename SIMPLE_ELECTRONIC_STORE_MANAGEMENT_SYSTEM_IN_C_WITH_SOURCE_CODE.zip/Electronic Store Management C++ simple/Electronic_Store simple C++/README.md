# Electronic_Store_Management_System

In the world today where economy, productivity and all such related factors are growing, even the ordinary shops are also growing. Every day their business is growing, their agencies and the products they ship go on increasing. With this as the case, the shopkeeper just can’t remember where he has stored each item in his shop, what the cost of each product is and what categories each of them belong to and much more.
	So in our project, we have taken a specific case of an Electronic Store where several categories of electronic components will be available. We have designed a system which provides the following options to the shopkeeper:
1.	Add new product 
2.	Display all products
3.	Modify the product’s record
4.	Delete a product
5.	Search a product
6.	Print the bill
So the shopkeeper can easily maintain his shop and handle many users at small time.
	The project has been implemented using the concepts of OOPS, file management and singly linked list. 

